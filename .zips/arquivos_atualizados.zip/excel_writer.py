from datetime import datetime
from pathlib import Path

import xlwings as xw

from config import COLUNAS, MESES

class ExcelWriter:
    def __init__(self):
        self.app = None
        self.wb = None

    def abrir(self):
        pasta_planilha = (
            Path(__file__).resolve().parent / "planilha"
        )

        arquivos = []

        for extensao in ("*.xlsm", "*.xlsx", "*.xls"):
            arquivos.extend(
                pasta_planilha.glob(extensao)
            )

        arquivos = [
            arquivo
            for arquivo in arquivos
            if not arquivo.name.startswith("~$")
        ]

        if not arquivos:
            raise FileNotFoundError(
                f"Nenhuma planilha encontrada em:\n"
                f"{pasta_planilha}"
            )

        if len(arquivos) > 1:
            nomes = "\n".join(
                f"- {arquivo.name}"
                for arquivo in arquivos
            )

            raise RuntimeError(
                "Foi encontrada mais de uma planilha:\n"
                f"{nomes}\n\n"
                "Deixe apenas uma planilha na pasta."
            )

        planilha = arquivos[0]

        print(
            f"Planilha encontrada: {planilha.name}"
        )

        self.app = xw.App(visible=False)

        self.app.display_alerts = False
        self.app.screen_updating = False

        self.wb = self.app.books.open(
            str(planilha)
        )

    def fechar(self):
        if self.wb:
            self.wb.save()
            self.wb.close()

        if self.app:
            self.app.quit()

    def nome_aba(self, data_operacao):
        data = datetime.strptime(
            data_operacao,
            "%d/%m/%Y"
        )

        mes = MESES[data.month]

        ano = str(data.year)[2:]

        return f"{mes} {ano}"

    def obter_aba(self, data_operacao):
        nome = self.nome_aba(
            data_operacao
        )

        return self.wb.sheets[nome]

    def primeira_linha_vazia(self, aba, limite=10000):
        # Leitura em lote: uma única chamada COM traz a coluna inteira,
        # em vez de uma chamada por célula. Isso evita deixar o processo
        # do Excel "ocupado" por muito tempo durante o loop, que era o
        # que causava o "Call was rejected by callee" / travamentos
        # quando o usuário mexia no computador antes do processo terminar.
        coluna = COLUNAS['cliente']

        valores = aba.range(
            f"{coluna}1:{coluna}{limite}"
        ).value

        for indice, valor in enumerate(valores, start=1):
            if valor is None:
                return indice

            if str(valor).strip() == "":
                return indice

        # Nenhuma linha vazia encontrada dentro do limite: assume a
        # próxima linha após o limite em vez de travar silenciosamente.
        return limite + 1

    def escrever_cheque(
        self,
        aba,
        linha,
        cheque
    ):
        aba.range(
            f"{COLUNAS['cliente']}{linha}"
        ).value = cheque["cliente"]

        aba.range(
            f"{COLUNAS['data']}{linha}"
        ).value = cheque["data"]

        aba.range(
            f"{COLUNAS['lote']}{linha}"
        ).value = cheque["lote"]

        aba.range(
            f"{COLUNAS['dias']}{linha}"
        ).value = int(
            cheque["dias"]
        )

        valor_face = float(
            cheque["valor_face"]
            .replace(".", "")
            .replace(",", ".")
        )

        valor_pago = float(
            cheque["valor_pago"]
            .replace(".", "")
            .replace(",", ".")
        )

        aba.range(
            f"{COLUNAS['valor_face']}{linha}"
        ).value = valor_face

        aba.range(
            f"{COLUNAS['valor_pago']}{linha}"
        ).value = valor_pago

    def importar_cheques(self, cheques):
        total = 0

        for cheque in cheques:
            try:
                aba = self.obter_aba(
                    cheque["data"]
                )

                linha = self.primeira_linha_vazia(
                    aba
                )

                self.escrever_cheque(
                    aba,
                    linha,
                    cheque
                )

                print(
                    f"[OK] "
                    f"{cheque['cliente']} -> "
                    f"{self.nome_aba(cheque['data'])} "
                    f"(linha {linha})"
                )

                total += 1

            except Exception as erro:
                print()
                print("=" * 60)
                print("ERRO AO IMPORTAR")
                print("=" * 60)

                print(
                    f"Cliente : "
                    f"{cheque['cliente']}"
                )

                print(
                    f"Lote    : "
                    f"{cheque['lote']}"
                )

                print(
                    f"Data    : "
                    f"{cheque['data']}"
                )

                print()
                print(erro)
                print("=" * 60)

        print()
        print("=" * 60)
        print(f"TOTAL IMPORTADO: {total}")
        print("=" * 60)


def importar_para_excel(cheques):
    excel = ExcelWriter()

    try:
        excel.abrir()
        excel.importar_cheques(cheques)

    finally:
        excel.fechar()
