from pathlib import Path

from pdf_reader import (
    ler_pdf,
    extrair_cabecalho,
    extrair_cheques
)
from excel_writer import importar_para_excel
PASTA_ENTRADA = Path("entrada")
def carregar_pdfs():

    todos_cheques = []

    arquivos = list(PASTA_ENTRADA.glob("*.pdf"))

    if not arquivos:

        print("Nenhum PDF encontrado.")

        return []

    print()
    print("=" * 60)
    print(f"{len(arquivos)} PDF(s) encontrado(s)")
    print("=" * 60)

    for pdf in arquivos:

        print()
        print(f"Lendo: {pdf.name}")

        try:

            texto = ler_pdf(pdf)

            cabecalho = extrair_cabecalho(texto)

            cheques = extrair_cheques(
                texto,
                cabecalho
            )

            print(
                f"{len(cheques)} cheque(s) encontrado(s)"
            )

            todos_cheques.extend(
                cheques
            )

        except Exception as erro:

            print()

            print("=" * 60)
            print("ERRO")
            print("=" * 60)

            print(pdf.name)

            print()

            print(erro)

    return todos_cheques


def main():

    cheques = carregar_pdfs()

    if not cheques:

        print()

        print("Nenhum cheque encontrado.")

        return

    print()

    print("=" * 60)
    print(f"TOTAL DE CHEQUES: {len(cheques)}")
    print("=" * 60)

    print()

    resposta = input(
        "Deseja importar para o Excel? (S/N): "
    ).strip().upper()

    if resposta != "S":

        print("Operação cancelada.")

        return

    importar_para_excel(
        cheques
    )

    print()

    print("=" * 60)
    print("IMPORTAÇÃO CONCLUÍDA")
    print("=" * 60)


if __name__ == "__main__":

    main()