---
name: Positivo Corporate Identity
colors:
  surface: '#f8f9fa'
  surface-dim: '#d9dadb'
  surface-bright: '#f8f9fa'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f4f5'
  surface-container: '#edeeef'
  surface-container-high: '#e7e8e9'
  surface-container-highest: '#e1e3e4'
  on-surface: '#191c1d'
  on-surface-variant: '#424752'
  inverse-surface: '#2e3132'
  inverse-on-surface: '#f0f1f2'
  outline: '#727784'
  outline-variant: '#c2c6d4'
  surface-tint: '#115cb9'
  primary: '#003f87'
  on-primary: '#ffffff'
  primary-container: '#0056b3'
  on-primary-container: '#bbd0ff'
  inverse-primary: '#acc7ff'
  secondary: '#00658d'
  on-secondary: '#ffffff'
  secondary-container: '#2dbcfe'
  on-secondary-container: '#004866'
  tertiary: '#722b00'
  on-tertiary: '#ffffff'
  tertiary-container: '#983c00'
  on-tertiary-container: '#ffc2a7'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d7e2ff'
  primary-fixed-dim: '#acc7ff'
  on-primary-fixed: '#001a40'
  on-primary-fixed-variant: '#004491'
  secondary-fixed: '#c6e7ff'
  secondary-fixed-dim: '#82cfff'
  on-secondary-fixed: '#001e2d'
  on-secondary-fixed-variant: '#004c6b'
  tertiary-fixed: '#ffdbcc'
  tertiary-fixed-dim: '#ffb694'
  on-tertiary-fixed: '#351000'
  on-tertiary-fixed-variant: '#7b2f00'
  background: '#f8f9fa'
  on-background: '#191c1d'
  surface-variant: '#e1e3e4'
typography:
  display-lg:
    fontFamily: Hanken Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 16px
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 8px
  container-margin: 24px
  gutter: 16px
  column-gap: 24px
  section-padding: 32px
---

## Brand & Style

This design system is built for a leading Brazilian technology context, prioritizing efficiency, reliability, and modern professional standards. The aesthetic follows a **Corporate / Modern** movement, characterized by balanced proportions, systematic spacing, and a focus on functional clarity. 

The target audience consists of enterprise professionals and power users who require a high-performance desktop productivity tool. The emotional response should be one of "effortless competence"—the UI stays out of the way of the work while providing a high-quality, polished environment. The design leverages crisp boundaries and a structured information hierarchy to maintain focus during long periods of use.

## Colors

The palette is anchored in a signature Brazilian "Positivo Blue," a deep, professional primary shade that evokes trust and technical stability.

- **Primary (#0056B3):** Used for main actions, active states, and brand-critical elements.
- **Secondary (#00AEEF):** A brighter blue used for supportive UI elements, highlights, and subtle gradients in data visualization.
- **Neutral (#F8F9FA):** A range of cool grays that provide a clean canvas. Backgrounds use the lightest shade to ensure high contrast for text.
- **Terminal (#1E1E1E):** A specific dark-mode override for technical components to provide visual relief and mimic professional IDE environments.

Color application should be conservative, using blue primarily for interactive affordances and functional feedback.

## Typography

The typography system utilizes **Hanken Grotesk** for its sharp, contemporary geometric forms that maintain excellent legibility in high-density corporate interfaces. It strikes a balance between professional utility and modern character.

For technical contexts and the terminal component, **JetBrains Mono** is used. This provides a clear distinction between narrative/UI text and system/data labels.

**Scale and Hierarchy:**
- Large displays are reserved for dashboard overviews.
- Body text uses a 16px base for optimal readability.
- Monospaced labels are used for ID tags, status codes, and terminal inputs to emphasize the "technology" aspect of the brand.

## Layout & Spacing

This design system employs a **Fluid Grid** model with a strictly defined 8px baseline rhythm. This ensures that all components align perfectly, creating a sense of engineering precision.

- **Desktop:** A 12-column grid with 24px gutters. Sidebars are fixed at 280px to maximize the working area for data-heavy tools.
- **Content Density:** High-density layouts are preferred. Use 8px and 16px increments for internal component spacing to keep the interface compact yet breathable.
- **Alignment:** All containers and cards must align to the grid edges. Padding within cards should be a consistent 24px to provide a generous inner-safe area.

## Elevation & Depth

To maintain a clean, professional look, the design system utilizes **Tonal Layers** and **Low-Contrast Outlines** rather than heavy shadows.

- **Surface Levels:** The primary background is the lowest level. Card containers are elevated using a pure white background and a subtle 1px border (#E9ECEF).
- **Interactive Depth:** On hover, cards transition to a slightly higher state using a soft, neutral-tinted shadow (0px 4px 12px rgba(0, 0, 0, 0.05)) to indicate interactivity without cluttering the visual field.
- **Separation:** Use vertical and horizontal dividers in light gray (#DEE2E6) to organize information within a single plane, reserving elevation changes only for major UI sections or modals.

## Shapes

The design system uses a **Soft** shape language. This provides a modern, approachable feel while maintaining the structural integrity expected of professional software.

- **Base Radius (4px):** Applied to standard buttons, input fields, and checkboxes.
- **Large Radius (8px):** Applied to card containers and modals to create a distinct visual container.
- **Terminal:** Should remain slightly sharper (2px or 4px) to emphasize its utility-first nature.

Avoid fully rounded "pill" shapes for primary actions to maintain the corporate, structured aesthetic.

## Components

### Buttons
Primary buttons use the Positivo Blue (#0056B3) with white text. Secondary buttons use a subtle gray outline. All buttons have a 4px radius and 40px standard height for desktop.

### Data Tables
Tables are the heart of the system. Use alternating row colors (zebra striping) in very light gray. Column headers use `label-sm` monospaced type for a technical feel. Rows must have a hover state that highlights in light blue.

### Drag & Drop Zones
Drop zones feature a dashed border (2px) in Positivo Blue with a 10% opacity blue fill. When a file is hovered over the zone, the border becomes solid and the background fill increases to 20% opacity.

### Terminal Component
A full-width container using the "Terminal" color (#1E1E1E). Text is rendered in JetBrains Mono in white or light green. The header of the terminal should include a simplified "window control" visual to distinguish it from standard cards.

### Input Fields
Inputs use a 1px border. On focus, the border transitions to Primary Blue with a 2px outer "glow" of the same color at 20% opacity. Labels are always visible above the field in `body-sm`.

### Cards
Defined by white backgrounds, 1px light gray borders, and 8px corner radius. Use cards to group related data points and technical parameters.