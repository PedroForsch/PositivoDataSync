import json
import sys
import threading
from pathlib import Path

import webview

from pdf_reader import ler_pdf, extrair_cabecalho, extrair_cheques
from excel_writer import ExcelWriter


def caminho_recurso(relativo):
    """Resolve caminhos tanto rodando via python quanto empacotado pelo PyInstaller."""
    base = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
    return str(base / relativo)


class Api:
    def __init__(self):
        self.window = None
        self.pdfs = []
        self.planilha = None

    # ---------- seleção de arquivos ----------

    def selecionar_pdfs(self):
        arquivos = self.window.create_file_dialog(
            webview.OPEN_DIALOG,
            allow_multiple=True,
            file_types=("Arquivos PDF (*.pdf)",),
        )

        if arquivos:
            for caminho in arquivos:
                if caminho not in self.pdfs:
                    self.pdfs.append(caminho)

        return [Path(p).name for p in self.pdfs]

    def remover_pdf(self, indice):
        if 0 <= indice < len(self.pdfs):
            self.pdfs.pop(indice)

        return [Path(p).name for p in self.pdfs]

    def selecionar_planilha(self):
        arquivos = self.window.create_file_dialog(
            webview.OPEN_DIALOG,
            allow_multiple=False,
            file_types=("Planilhas Excel (*.xlsm;*.xlsx;*.xls)",),
        )

        if arquivos:
            self.planilha = arquivos[0]
            return Path(self.planilha).name

        return None

    def remover_planilha(self):
        self.planilha = None
        return None

    # ---------- processamento ----------

    def _log(self, mensagem):
        if self.window:
            self.window.evaluate_js(
                f"appendLog({json.dumps(mensagem)})"
            )

    def processar(self):
        if not self.pdfs:
            return {"ok": False, "mensagem": "Selecione ao menos um PDF na aba 'Arquivos PDF'."}

        if not self.planilha:
            return {"ok": False, "mensagem": "Selecione a planilha Excel na aba 'Planilha Excel'."}

        thread = threading.Thread(target=self._processar_thread, daemon=True)
        thread.start()

        return {"ok": True}

    def _processar_thread(self):
        try:
            self._log("=" * 60)
            self._log(f"{len(self.pdfs)} PDF(s) para processar")
            self._log("=" * 60)

            todos_cheques = []
            erros_leitura = 0

            for caminho in self.pdfs:
                nome = Path(caminho).name
                self._log(f"Lendo: {nome}")

                try:
                    texto = ler_pdf(caminho)
                    cabecalho = extrair_cabecalho(texto)
                    cheques = extrair_cheques(texto, cabecalho)

                    self._log(
                        f"  -> {len(cheques)} título(s) encontrado(s) "
                        f"({cabecalho['cliente']})"
                    )

                    todos_cheques.extend(cheques)

                except Exception as erro:
                    self._log(f"  [ERRO] {erro}")
                    erros_leitura += 1

            if not todos_cheques:
                self._log("")
                self._log("Nenhum título encontrado nos PDFs.")

                self.window.evaluate_js(
                    "processoFinalizado("
                    + json.dumps({"ok": False, "mensagem": "Nenhum título encontrado nos PDFs."})
                    + ")"
                )
                return

            self._log("")
            self._log(f"Total de títulos a importar: {len(todos_cheques)}")
            self._log("Abrindo planilha...")

            excel = ExcelWriter()
            excel.abrir(self.planilha)

            total_importado = 0
            erros_importacao = 0

            try:
                for cheque in todos_cheques:
                    try:
                        aba = excel.obter_aba(cheque["data"])
                        linha = excel.primeira_linha_vazia(aba)
                        excel.escrever_cheque(aba, linha, cheque)

                        self._log(
                            f"  [OK] {cheque['cliente']} -> "
                            f"{excel.nome_aba(cheque['data'])} (linha {linha})"
                        )

                        total_importado += 1

                    except Exception as erro:
                        self._log(f"  [ERRO] {cheque['cliente']}: {erro}")
                        erros_importacao += 1

            finally:
                excel.fechar()

            self._log("")
            self._log("=" * 60)
            self._log(
                f"CONCLUÍDO: {total_importado} de {len(todos_cheques)} "
                f"título(s) importado(s)"
            )
            self._log("=" * 60)

            resultado = {
                "ok": True,
                "total": len(todos_cheques),
                "importado": total_importado,
                "erros_leitura": erros_leitura,
                "erros_importacao": erros_importacao,
            }

            self.window.evaluate_js(
                f"processoFinalizado({json.dumps(resultado)})"
            )

        except Exception as erro:
            self._log(f"[ERRO GERAL] {erro}")

            self.window.evaluate_js(
                "processoFinalizado("
                + json.dumps({"ok": False, "mensagem": str(erro)})
                + ")"
            )


def main():
    api = Api()

    window = webview.create_window(
        "Positivo DataSync - Importador de Borderôs",
        caminho_recurso("index.html"),
        js_api=api,
        width=1080,
        height=760,
        min_size=(860, 620),
    )

    api.window = window

    webview.start()


if __name__ == "__main__":
    main()
