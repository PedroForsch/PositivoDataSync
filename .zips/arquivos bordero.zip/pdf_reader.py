import pdfplumber
import re


def ler_pdf(caminho):

    texto = ""

    with pdfplumber.open(caminho) as pdf:
        for pagina in pdf.pages:
            conteudo = pagina.extract_text()

            if conteudo:
                texto += conteudo + "\n"

    return texto


def extrair_cabecalho(texto):

    dados = {}

    m = re.search(r"Cedente:\s*(.+)", texto)
    dados["cliente"] = m.group(1).strip() if m else ""

    m = re.search(r"N\.Border[oô]:\s*(\d+)", texto)
    dados["lote"] = m.group(1).strip() if m else ""

    m = re.search(r"Data:\s*(\d{2}/\d{2}/\d{4})", texto)
    dados["data"] = m.group(1).strip() if m else ""

    return dados


PADRAO_TITULO = re.compile(
    r"^(DM|DS)\s+"          # tipo
    r"(\d+)\s+"             # documento (CPF/CNPJ do sacado)
    r"(.+?)\s+"             # sacado (nome, não-guloso)
    r"(\S+)\s+"             # numero do titulo
    r"(\d{2}/\d{2}/\d{4})\s+"  # vencimento
    r"([\d\.,]+)\s+"        # valor (face)
    r"(\d+)\s+"             # dias
    r"([\d\.,]+)\s+"        # fator/adv
    r"([\d\.,]+)\s+"        # impostos
    r"([\d\.,]+)\s+"        # tarifas
    r"([\d\.,]+)\s*$"       # liquido (valor pago)
)


def extrair_cheques(texto, cabecalho):

    cheques = []

    linhas = texto.splitlines()

    for linha in linhas:

        m = PADRAO_TITULO.match(linha.strip())

        if not m:
            continue

        (
            tipo,
            documento,
            sacado,
            numero,
            vencimento,
            valor,
            dias,
            fator_adv,
            impostos,
            tarifas,
            liquido,
        ) = m.groups()

        cheques.append({
            "cliente": cabecalho["cliente"],
            "data": cabecalho["data"],
            "lote": cabecalho["lote"],
            "tipo": tipo,
            "documento": documento,
            "sacado": sacado.strip(),
            "numero": numero,
            "vencimento": vencimento,
            "valor_face": valor,
            "dias": dias,
            "valor_pago": liquido,
        })

    return cheques
